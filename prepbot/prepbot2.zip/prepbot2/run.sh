conda activate py36
ipython
